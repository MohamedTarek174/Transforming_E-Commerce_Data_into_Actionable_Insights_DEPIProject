# CSV Export

Generated on 2024-09-15 15:27:08.621312339 UTC by Fabricate v0.1.0

## Exported tables

This is the list of exported tables, with their corresponding row count and file names:

    public.Customers: 100 rows => public-Customers-f27b41448089b25168042d8312349e495d0c2d8044205d9636fd37f92d1801b9.csv
    public.Inventory: 100 rows => public-Inventory-8f2889a91d8de5a07317ac22ce6c6a2fc2f95784911454672b550deb700977e4.csv
    public.OrderItems: 100 rows => public-OrderItems-db5213bc960def4ebb66dfe539c18d5f3abb0a22982918e18786d94285b5635f.csv
    public.Orders: 100 rows => public-Orders-29aa96791f262131dc77096f8ec3f594ce892742e167e581046463a84ba46ce1.csv
    public.Payments: 100 rows => public-Payments-01233a7e9091a6255d903dd6f0c60f9c275354aff8aa9cdc66608d2f12feca53.csv
    public.Products: 100 rows => public-Products-98dc0b191402f2319df3bfcc40fc6b3fff20c34986a5b558605fe601539400ba.csv
    public.Promotions: 100 rows => public-Promotions-8a9b86aa532455708b2d449837813c3249ddd7bfa91eae0c103b3ad9274891dc.csv
    public.Reviews: 100 rows => public-Reviews-3b4600f736458fb197e3bd814dafa4cc1c28621318bf3e3376d875ae1bc5ef7f.csv